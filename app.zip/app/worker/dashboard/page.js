'use client';
import { useState, useEffect } from 'react';
import { collection, query, where, getDocs, doc, updateDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import styles from './page.module.css';

export default function WorkerDashboard() {
  const router = useRouter();
  const [worker, setWorker] = useState(null);
  const [jobs, setJobs] = useState([]);
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem('fixstar_worker');
    if (!stored) { router.push('/auth/worker/login'); return; }
    const w = JSON.parse(stored);
    setWorker(w);
    loadJobs(w.uid);
  }, []);

  const loadJobs = async (uid) => {
    setLoading(true);
    try {
      const snap = await getDocs(query(collection(db, 'bookings'), where('workerId', '==', uid)));
      setJobs(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (e) { console.error(e); }
    setLoading(false);
  };

  const updateJobStatus = async (jobId, status) => {
    await updateDoc(doc(db, 'bookings', jobId), { status });
    setJobs(prev => prev.map(j => j.id === jobId ? { ...j, status } : j));
  };

  const handleLogout = () => {
    localStorage.removeItem('fixstar_worker');
    router.push('/');
  };

  const pendingJobs = jobs.filter(j => j.status === 'pending');
  const activeJobs = jobs.filter(j => j.status === 'in_progress');
  const completedJobs = jobs.filter(j => j.status === 'completed');
  const totalEarnings = completedJobs.length * 50; // placeholder

  if (loading) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '100vh' }}>
      <div className="spinner" style={{ width: 48, height: 48 }}></div>
    </div>
  );

  const isPending = worker?.status === 'pending';

  return (
    <div className={styles.layout}>
      {/* Sidebar */}
      <aside className={styles.sidebar}>
        <div className={styles.sidebarTop}>
          <Link href="/" className={styles.logo}>
            <span style={{ color: 'var(--gold)' }}>★</span> FIXStar
          </Link>
          <div className={styles.workerInfo}>
            <div className={styles.workerAvatar}>{worker?.name?.charAt(0)}</div>
            <div>
              <p className={styles.workerName}>{worker?.name}</p>
              <span className={styles.workerId}>{worker?.localId}</span>
            </div>
          </div>
          <span className={`badge ${isPending ? 'badge-warning' : 'badge-success'}`} style={{ marginTop: 10 }}>
            {isPending ? '⏳ Pending Approval' : '✅ Active Worker'}
          </span>
        </div>

        <nav className={styles.sidebarNav}>
          {[
            { id: 'overview', icon: '📊', label: 'Overview' },
            { id: 'jobs', icon: '🔧', label: 'My Jobs' },
            { id: 'earnings', icon: '💰', label: 'Earnings' },
            { id: 'profile', icon: '👤', label: 'My Profile' },
          ].map(item => (
            <button
              key={item.id}
              className={`${styles.navItem} ${activeTab === item.id ? styles.navActive : ''}`}
              onClick={() => setActiveTab(item.id)}
            >
              <span>{item.icon}</span> {item.label}
            </button>
          ))}
        </nav>

        <button className={styles.logoutBtn} onClick={handleLogout}>🚪 Logout</button>
      </aside>

      {/* Main Content */}
      <main className={styles.main}>
        {isPending && (
          <div className={styles.pendingBanner}>
            <span>⏳</span>
            <div>
              <strong>Your account is under review</strong>
              <p>Our admin team is reviewing your documents. You'll be able to receive jobs once approved.</p>
            </div>
          </div>
        )}

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="animate-fade-in">
            <div className="page-header">
              <h1>Welcome back, <span className="gradient-text">{worker?.name?.split(' ')[0]}</span>!</h1>
              <p>Here's your performance overview</p>
            </div>
            <div className={styles.statsGrid}>
              {[
                { label: 'Pending Jobs', value: pendingJobs.length, icon: '⏳', color: 'var(--warning)' },
                { label: 'Active Jobs', value: activeJobs.length, icon: '🔧', color: 'var(--purple-glow)' },
                { label: 'Completed Jobs', value: completedJobs.length, icon: '✅', color: 'var(--success)' },
                { label: 'Total Earnings', value: `$${totalEarnings}`, icon: '💰', color: 'var(--gold)' },
              ].map(s => (
                <div key={s.label} className={`card ${styles.statCard}`}>
                  <div className={styles.statIcon} style={{ color: s.color }}>{s.icon}</div>
                  <div className={styles.statValue} style={{ color: s.color }}>{s.value}</div>
                  <div className={styles.statLabel}>{s.label}</div>
                </div>
              ))}
            </div>

            <h2 style={{ marginBottom: 16, marginTop: 32 }}>Recent Jobs</h2>
            {jobs.length === 0 ? (
              <div className={styles.empty}>
                <span>🔧</span>
                <p>No jobs yet. Complete your profile to get hired!</p>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {jobs.slice(0, 5).map(job => (
                  <JobCard key={job.id} job={job} onUpdate={updateJobStatus} />
                ))}
              </div>
            )}
          </div>
        )}

        {/* Jobs Tab */}
        {activeTab === 'jobs' && (
          <div className="animate-fade-in">
            <div className="page-header">
              <h1>My <span className="gradient-text">Jobs</span></h1>
              <p>Manage your service requests</p>
            </div>
            {['pending', 'in_progress', 'completed'].map(status => {
              const filtered = jobs.filter(j => j.status === status);
              if (filtered.length === 0) return null;
              return (
                <div key={status} style={{ marginBottom: 32 }}>
                  <h3 style={{ marginBottom: 14, textTransform: 'capitalize', color: 'var(--white-60)', fontSize: 14, letterSpacing: 1 }}>
                    {status.replace('_', ' ')} ({filtered.length})
                  </h3>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                    {filtered.map(job => (
                      <JobCard key={job.id} job={job} onUpdate={updateJobStatus} showActions />
                    ))}
                  </div>
                </div>
              );
            })}
            {jobs.length === 0 && (
              <div className={styles.empty}><span>📋</span><p>No jobs assigned yet.</p></div>
            )}
          </div>
        )}

        {/* Earnings Tab */}
        {activeTab === 'earnings' && (
          <div className="animate-fade-in">
            <div className="page-header">
              <h1>My <span className="gradient-text">Earnings</span></h1>
              <p>Track your income and payment history</p>
            </div>
            <div className={styles.earningsBanner}>
              <div className={styles.earningsTotal}>
                <span>Total Earnings</span>
                <strong>${totalEarnings}.00</strong>
              </div>
              <div className={styles.earningsBreakdown}>
                <div><span>Jobs Completed</span><strong>{completedJobs.length}</strong></div>
                <div><span>Platform Commission</span><strong>15%</strong></div>
                <div><span>Your Share</span><strong>85%</strong></div>
              </div>
            </div>

            <div className={styles.stripeSection}>
              <h3>💳 Stripe Payment Account</h3>
              <p>Connect your Stripe account to receive payments directly when customers pay for your services.</p>
              <button className="btn btn-purple" style={{ marginTop: 16 }}
                onClick={() => window.open('/api/stripe/connect', '_blank')}>
                Connect Stripe Account →
              </button>
            </div>
          </div>
        )}

        {/* Profile Tab */}
        {activeTab === 'profile' && (
          <div className="animate-fade-in">
            <div className="page-header">
              <h1>My <span className="gradient-text">Profile</span></h1>
              <p>Your worker profile and credentials</p>
            </div>
            <div className={`card ${styles.profileCard}`}>
              <div className={styles.profileHeader}>
                <div className={styles.profileAvatar}>{worker?.name?.charAt(0)}</div>
                <div>
                  <h2>{worker?.name}</h2>
                  <p className={styles.workerId}>{worker?.localId}</p>
                  <p style={{ color: 'var(--white-60)', fontSize: 14 }}>{worker?.email}</p>
                </div>
              </div>
              <div className="divider-gold"></div>
              <div className={styles.profileInfo}>
                <div className={styles.profileRow}>
                  <span>Status</span>
                  <span className={`badge ${isPending ? 'badge-warning' : 'badge-success'}`}>
                    {isPending ? 'Pending Approval' : 'Active'}
                  </span>
                </div>
                <div className={styles.profileRow}>
                  <span>Worker ID</span>
                  <strong>{worker?.localId}</strong>
                </div>
                <div className={styles.profileRow}>
                  <span>Jobs Completed</span>
                  <strong>{completedJobs.length}</strong>
                </div>
                <div className={styles.profileRow}>
                  <span>Rating</span>
                  <strong>⭐ 5.0</strong>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

function JobCard({ job, onUpdate, showActions }) {
  const statusColors = {
    pending: 'badge-warning',
    in_progress: 'badge-purple',
    completed: 'badge-success',
    cancelled: 'badge-danger',
  };
  return (
    <div className={`card ${styles.jobCard}`}>
      <div className={styles.jobHeader}>
        <div>
          <h4>{job.service}</h4>
          <p style={{ color: 'var(--white-60)', fontSize: 13 }}>
            👤 {job.customerName} · 📍 {job.address}
          </p>
          <p style={{ color: 'var(--white-60)', fontSize: 13, marginTop: 4 }}>📅 {job.scheduledDate}</p>
        </div>
        <span className={`badge ${statusColors[job.status] || 'badge-warning'}`}>{job.status?.replace('_', ' ')}</span>
      </div>
      {job.notes && <p style={{ fontSize: 13, color: 'var(--white-60)', marginTop: 8 }}>📝 {job.notes}</p>}
      {showActions && job.status === 'pending' && (
        <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
          <button className="btn btn-success btn-sm" onClick={() => onUpdate(job.id, 'in_progress')}>Accept Job</button>
          <button className="btn btn-danger btn-sm" onClick={() => onUpdate(job.id, 'cancelled')}>Decline</button>
        </div>
      )}
      {showActions && job.status === 'in_progress' && (
        <button className="btn btn-gold btn-sm" style={{ marginTop: 14 }} onClick={() => onUpdate(job.id, 'completed')}>
          ✅ Mark as Completed
        </button>
      )}
    </div>
  );
}
