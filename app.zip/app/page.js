'use client';
import Navbar from '@/components/Navbar/Navbar';
import Link from 'next/link';
import styles from './page.module.css';

const services = [
  { icon: '❄️', title: 'Cooling Systems', desc: 'AC repair, refrigerator maintenance & installation', color: '#38BDF8' },
  { icon: '🫧', title: 'Washing Machine', desc: 'Repair & servicing of all washing machine brands', color: '#818CF8' },
  { icon: '🛋️', title: 'Furniture Fixing', desc: 'Assembly, repair & restoration of furniture', color: '#F59E0B' },
  { icon: '⚡', title: 'Electronics', desc: 'Home electronics, TVs, appliances & gadgets', color: '#A78BFA' },
  { icon: '🔧', title: 'Electric & Plumbing', desc: 'Full electrical wiring, pipes & plumbing work', color: '#34D399' },
  { icon: '🏗️', title: 'Construction', desc: 'Building design, renovation & construction work', color: '#FB923C' },
];

const steps = [
  { num: '01', title: 'Choose a Service', desc: 'Browse our wide range of repair and construction services.' },
  { num: '02', title: 'Book a Worker', desc: 'Select a verified professional with the right skills for your job.' },
  { num: '03', title: 'Pay Securely', desc: 'Pay through Stripe. Worker gets paid, you get the job done.' },
];

const stats = [
  { value: '500+', label: 'Verified Workers' },
  { value: '2,000+', label: 'Jobs Completed' },
  { value: '4.9★', label: 'Average Rating' },
  { value: '15min', label: 'Avg Response Time' },
];

export default function HomePage() {
  return (
    <main className={styles.main}>
      <Navbar />

      {/* ── Hero ── */}
      <section className={styles.hero}>
        <div className={styles.heroBg}>
          <div className={styles.orb1}></div>
          <div className={styles.orb2}></div>
          <div className={styles.grid}></div>
        </div>
        <div className={`container ${styles.heroContent}`}>
          <div className={styles.heroBadge}>
            <span className={styles.badgeDot}></span>
            Trusted by 2,000+ happy customers
          </div>
          <h1 className={styles.heroTitle}>
            Your One-Stop<br />
            <span className="gradient-text">Repair & Build</span><br />
            Platform
          </h1>
          <p className={styles.heroSubtitle}>
            FIXStar connects you with verified professionals for all your repair,
            maintenance, and construction needs — fast, reliable, and affordable.
          </p>
          <div className={styles.heroCtas}>
            <Link href="/auth/customer" className="btn btn-gold btn-lg">
              🔍 Find a Worker
            </Link>
            <Link href="/auth/worker/register" className="btn btn-ghost btn-lg">
              👷 Join as Worker
            </Link>
          </div>
          <div className={styles.heroStats}>
            {stats.map((s) => (
              <div key={s.label} className={styles.statItem}>
                <span className={styles.statValue}>{s.value}</span>
                <span className={styles.statLabel}>{s.label}</span>
              </div>
            ))}
          </div>
        </div>
        <div className={styles.heroLogoWrap}>
          <img src="/logo.jpg" alt="FIXStar Logo" className={styles.heroLogoImg} />
        </div>
      </section>

      {/* ── Services ── */}
      <section id="services" className={`section ${styles.services}`}>
        <div className="container">
          <div className={styles.sectionHead}>
            <span className="badge badge-gold">Our Services</span>
            <h2 className="section-title" style={{textAlign:'center', marginTop:16}}>
              Everything You <span className="gradient-text">Need Fixed</span>
            </h2>
            <p className="section-subtitle">
              From quick repairs to full construction projects — our verified workers handle it all.
            </p>
          </div>
          <div className={`grid-3 ${styles.servicesGrid}`}>
            {services.map((s) => (
              <Link href="/auth/customer" key={s.title} className={`card card-hover ${styles.serviceCard}`}>
                <div className={styles.serviceIcon} style={{ background: `${s.color}18`, border: `1px solid ${s.color}30` }}>
                  <span style={{ fontSize: 32 }}>{s.icon}</span>
                </div>
                <h3 className={styles.serviceTitle}>{s.title}</h3>
                <p className={styles.serviceDesc}>{s.desc}</p>
                <span className={styles.serviceArrow}>→</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── How It Works ── */}
      <section id="how-it-works" className={`section ${styles.howSection}`}>
        <div className="container">
          <div className={styles.sectionHead}>
            <span className="badge badge-purple">Simple Process</span>
            <h2 className="section-title" style={{textAlign:'center', marginTop:16}}>
              How <span className="purple-gradient-text">FIXStar</span> Works
            </h2>
            <p className="section-subtitle">Get your job done in 3 simple steps</p>
          </div>
          <div className={styles.steps}>
            {steps.map((step, i) => (
              <div key={step.num} className={styles.step}>
                <div className={styles.stepNum}>{step.num}</div>
                {i < steps.length - 1 && <div className={styles.stepLine}></div>}
                <div className={styles.stepContent}>
                  <h3 className={styles.stepTitle}>{step.title}</h3>
                  <p className={styles.stepDesc}>{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA Banner ── */}
      <section className={`section-sm ${styles.ctaSection}`}>
        <div className="container">
          <div className={styles.ctaBanner}>
            <div className={styles.ctaBannerGlow}></div>
            <h2 className={styles.ctaTitle}>Ready to Get Started?</h2>
            <p className={styles.ctaDesc}>Join thousands of satisfied customers and skilled workers on FIXStar.</p>
            <div className={styles.ctaButtons}>
              <Link href="/auth/customer" className="btn btn-gold btn-lg">Book a Service Now</Link>
              <Link href="/auth/worker/register" className="btn btn-outline btn-lg">Register as Worker</Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── Footer ── */}
      <footer className={styles.footer}>
        <div className="container">
          <div className={styles.footerTop}>
            <div className={styles.footerBrand}>
              <div className={styles.footerLogo} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <img src="/logo.jpg" alt="FIXStar Logo" style={{ height: 32, width: 'auto', borderRadius: 6, border: '1px solid rgba(212,175,55,0.3)' }} />
                <span>FIX<span style={{ color: 'var(--gold)' }}>Star</span></span>
              </div>
              <p className={styles.footerTagline}>Create • Repair • Upgrade</p>
            </div>
            <div className={styles.footerLinks}>
              <div className={styles.footerCol}>
                <h4>Services</h4>
                <a href="#services">Cooling Systems</a>
                <a href="#services">Washing Machines</a>
                <a href="#services">Furniture Fixing</a>
                <a href="#services">Electronics</a>
                <a href="#services">Electric & Plumbing</a>
              </div>
              <div className={styles.footerCol}>
                <h4>Platform</h4>
                <Link href="/auth/customer">Customer Login</Link>
                <Link href="/auth/worker/login">Worker Login</Link>
                <Link href="/auth/worker/register">Become a Worker</Link>
              </div>
            </div>
          </div>
          <div className="divider"></div>
          <div className={styles.footerBottom}>
            <p>© 2024 FIXStar. All rights reserved.</p>
            <p style={{color:'var(--white-60)'}}>Create • Repair • Upgrade</p>
          </div>
        </div>
      </footer>
    </main>
  );
}
