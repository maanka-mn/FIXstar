import { NextResponse } from 'next/server';
import Stripe from 'stripe';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || 'sk_test_placeholder');

export async function POST(request) {
  const body = await request.text();
  const sig = request.headers.get('stripe-signature');

  let event;
  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    return NextResponse.json({ error: 'Webhook signature failed.' }, { status: 400 });
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const { bookingId } = session.metadata || {};
    if (bookingId) {
      try {
        await updateDoc(doc(db, 'bookings', bookingId), {
          paymentStatus: 'paid',
          stripeSessionId: session.id,
          paidAt: new Date().toISOString(),
        });
      } catch (err) {
        console.error('Firestore update error:', err);
      }
    }
  }

  return NextResponse.json({ received: true });
}
