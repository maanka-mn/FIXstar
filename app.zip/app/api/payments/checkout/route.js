import { NextResponse } from 'next/server';
import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || 'sk_test_placeholder');
const COMMISSION = parseInt(process.env.PLATFORM_COMMISSION_PERCENT || '15');

export async function POST(request) {
  try {
    const { bookingId, service, amount, workerStripeId, customerEmail, workerName } = await request.json();
    const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';

    // Amount in cents
    const totalCents = Math.round((amount || 50) * 100);
    const platformFee = Math.floor(totalCents * COMMISSION / 100);

    const sessionParams = {
      payment_method_types: ['card'],
      line_items: [{
        price_data: {
          currency: 'usd',
          product_data: {
            name: service || 'FIXStar Service',
            description: `Service by ${workerName || 'FIXStar Worker'}`,
          },
          unit_amount: totalCents,
        },
        quantity: 1,
      }],
      mode: 'payment',
      customer_email: customerEmail,
      metadata: { bookingId, workerStripeId, platformFee },
      success_url: `${appUrl}/customer/dashboard?payment=success`,
      cancel_url: `${appUrl}/customer/dashboard?payment=cancelled`,
    };

    // If worker has Stripe account, set up transfer
    if (workerStripeId) {
      sessionParams.payment_intent_data = {
        application_fee_amount: platformFee,
        transfer_data: { destination: workerStripeId },
      };
    }

    const session = await stripe.checkout.sessions.create(sessionParams);
    return NextResponse.json({ url: session.url, sessionId: session.id });
  } catch (err) {
    console.error('Checkout error:', err);
    return NextResponse.json({ error: 'Checkout failed.' }, { status: 500 });
  }
}
