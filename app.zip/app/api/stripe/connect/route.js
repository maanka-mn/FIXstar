import { NextResponse } from 'next/server';
import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || 'sk_test_placeholder');

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const workerId = searchParams.get('workerId');

    if (!workerId) {
      return NextResponse.json({ error: 'Worker ID required.' }, { status: 400 });
    }

    const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';

    const account = await stripe.accounts.create({
      type: 'express',
      capabilities: { transfers: { requested: true } },
      metadata: { workerId },
    });

    const accountLink = await stripe.accountLinks.create({
      account: account.id,
      refresh_url: `${appUrl}/worker/dashboard`,
      return_url: `${appUrl}/worker/dashboard?stripe=success`,
      type: 'account_onboarding',
    });

    return NextResponse.redirect(accountLink.url);
  } catch (err) {
    console.error('Stripe connect error:', err);
    return NextResponse.json({ error: 'Stripe setup failed.' }, { status: 500 });
  }
}
