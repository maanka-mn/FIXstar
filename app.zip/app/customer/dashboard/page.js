'use client';
import { useState, useEffect } from 'react';
import { collection, getDocs, addDoc, serverTimestamp, query, where, doc, getDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import styles from './page.module.css';

const serviceCategories = [
  { icon: '❄️', title: 'Cooling Systems', key: 'Cooling Systems (AC / Refrigerator)' },
  { icon: '🫧', title: 'Washing Machine', key: 'Washing Machine Repair' },
  { icon: '🛋️', title: 'Furniture', key: 'Furniture Fixing & Making' },
  { icon: '⚡', title: 'Electronics', key: 'Electronic Machines' },
  { icon: '🔌', title: 'Electrical', key: 'Electrical Installation' },
  { icon: '🔧', title: 'Plumbing', key: 'Plumbing & Piping' },
];

export default function CustomerDashboard() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [workers, setWorkers] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [selectedService, setSelectedService] = useState('');
  const [activeTab, setActiveTab] = useState('services');
  const [loading, setLoading] = useState(true);
  const [bookingWorker, setBookingWorker] = useState(null);
  const [bookingForm, setBookingForm] = useState({ address: '', notes: '', date: '' });
  const [bookingLoading, setBookingLoading] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem('fixstar_user');
    if (!stored) { router.push('/auth/customer'); return; }
    const u = JSON.parse(stored);
    setUser(u);
    loadData(u.uid);
  }, []);

  const loadData = async (uid) => {
    setLoading(true);
    try {
      // Load approved workers
      const wSnap = await getDocs(query(collection(db, 'workers'), where('status', '==', 'approved')));
      setWorkers(wSnap.docs.map(d => ({ id: d.id, ...d.data() })));
      // Load customer bookings
      const bSnap = await getDocs(query(collection(db, 'bookings'), where('customerId', '==', uid)));
      setBookings(bSnap.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (e) { console.error(e); }
    setLoading(false);
  };

  const filteredWorkers = selectedService
    ? workers.filter(w => w.skills?.includes(selectedService))
    : workers;

  const handleBook = async (e) => {
    e.preventDefault();
    if (!bookingWorker || !bookingForm.address || !bookingForm.date) return;
    setBookingLoading(true);
    try {
      await addDoc(collection(db, 'bookings'), {
        customerId: user.uid, customerName: user.name, customerEmail: user.email,
        workerId: bookingWorker.uid, workerName: bookingWorker.fullName,
        workerLocalId: bookingWorker.localId,
        service: selectedService || bookingWorker.skills?.[0],
        address: bookingForm.address, notes: bookingForm.notes,
        scheduledDate: bookingForm.date,
        status: 'pending', paymentStatus: 'unpaid',
        createdAt: serverTimestamp(),
      });
      setBookingSuccess(true);
      setBookingWorker(null);
      setBookingForm({ address: '', notes: '', date: '' });
      if (user) loadData(user.uid);
    } catch (e) { console.error(e); }
    setBookingLoading(false);
  };

  const [payLoading, setPayLoading] = useState({});

  const handlePayment = async (booking) => {
    setPayLoading(prev => ({ ...prev, [booking.id]: true }));
    try {
      const wDoc = await getDoc(doc(db, 'workers', booking.workerId));
      const workerData = wDoc.exists() ? wDoc.data() : {};
      const workerStripeId = workerData.stripeConnectId || '';

      const res = await fetch('/api/payments/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bookingId: booking.id,
          service: booking.service,
          amount: 50,
          workerStripeId,
          customerEmail: user.email,
          workerName: booking.workerName,
        }),
      });
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        alert('Could not initiate payment. Try again.');
      }
    } catch (e) {
      console.error(e);
      alert('Error connecting to payment gateway.');
    } finally {
      setPayLoading(prev => ({ ...prev, [booking.id]: false }));
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('fixstar_user');
    router.push('/');
  };

  if (loading) return (
    <div style={{display:'flex',alignItems:'center',justifyContent:'center',minHeight:'100vh'}}>
      <div className="spinner" style={{width:48,height:48}}></div>
    </div>
  );

  return (
    <div className={styles.layout}>
      {/* Sidebar */}
      <aside className={styles.sidebar}>
        <div className={styles.sidebarTop}>
          <Link href="/" className={styles.logo}>
            <span style={{color:'var(--gold)'}}>★</span> FIXStar
          </Link>
          <div className={styles.userInfo}>
            {user?.photo && <img src={user.photo} alt={user.name} className={styles.avatar} />}
            <div>
              <p className={styles.userName}>{user?.name}</p>
              <span className="badge badge-gold" style={{fontSize:11}}>Customer</span>
            </div>
          </div>
        </div>

        <nav className={styles.sidebarNav}>
          {[
            { id: 'services', icon: '🔍', label: 'Browse Services' },
            { id: 'bookings', icon: '📋', label: 'My Bookings' },
          ].map(item => (
            <button
              key={item.id}
              className={`${styles.navItem} ${activeTab === item.id ? styles.navActive : ''}`}
              onClick={() => setActiveTab(item.id)}
            >
              <span>{item.icon}</span> {item.label}
            </button>
          ))}
        </nav>

        <button className={styles.logoutBtn} onClick={handleLogout}>
          🚪 Logout
        </button>
      </aside>

      {/* Main */}
      <main className={styles.main}>
        {/* Services Tab */}
        {activeTab === 'services' && (
          <div className="animate-fade-in">
            <div className="page-header">
              <h1>Find a <span className="gradient-text">Service</span></h1>
              <p>Browse verified workers and book the service you need</p>
            </div>

            {/* Service Filter */}
            <div className={styles.serviceFilters}>
              <button
                className={`${styles.filterBtn} ${!selectedService ? styles.filterActive : ''}`}
                onClick={() => setSelectedService('')}
              >All Services</button>
              {serviceCategories.map(s => (
                <button
                  key={s.key}
                  className={`${styles.filterBtn} ${selectedService === s.key ? styles.filterActive : ''}`}
                  onClick={() => setSelectedService(s.key)}
                >
                  {s.icon} {s.title}
                </button>
              ))}
            </div>

            {/* Workers Grid */}
            {filteredWorkers.length === 0 ? (
              <div className={styles.empty}>
                <span>👷</span>
                <p>No workers available for this service yet.</p>
              </div>
            ) : (
              <div className={styles.workersGrid}>
                {filteredWorkers.map(worker => (
                  <div key={worker.id} className={`card ${styles.workerCard}`}>
                    <div className={styles.workerHeader}>
                      <div className={styles.workerAvatar}>
                        {worker.fullName?.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <h3 className={styles.workerName}>{worker.fullName}</h3>
                        <span className={styles.workerId}>{worker.localId}</span>
                      </div>
                      <span className="badge badge-success" style={{marginLeft:'auto'}}>Active</span>
                    </div>
                    <p className={styles.workerBio}>{worker.bio || 'Experienced professional ready to help.'}</p>
                    <div className={styles.workerSkills}>
                      {worker.skills?.slice(0,3).map(s => (
                        <span key={s} className={styles.workerSkillTag}>{s}</span>
                      ))}
                    </div>
                    <div className={styles.workerMeta}>
                      <span>⭐ {worker.rating || '5.0'}</span>
                      <span>✅ {worker.jobsCompleted || 0} jobs</span>
                      <span>📅 {worker.experience || 'Experienced'}</span>
                    </div>
                    <button
                      className="btn btn-gold btn-full"
                      style={{marginTop:16}}
                      onClick={() => { setBookingWorker(worker); setBookingSuccess(false); }}
                    >
                      Book Now
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Bookings Tab */}
        {activeTab === 'bookings' && (
          <div className="animate-fade-in">
            <div className="page-header">
              <h1>My <span className="gradient-text">Bookings</span></h1>
              <p>Track all your service requests</p>
            </div>
            {bookings.length === 0 ? (
              <div className={styles.empty}>
                <span>📋</span>
                <p>You haven't made any bookings yet.</p>
                <button className="btn btn-gold" style={{marginTop:16}} onClick={() => setActiveTab('services')}>
                  Browse Services
                </button>
              </div>
            ) : (
              <div style={{display:'flex',flexDirection:'column',gap:16}}>
                {bookings.map(b => (
                  <div key={b.id} className={`card ${styles.bookingCard}`}>
                    <div className={styles.bookingHeader}>
                      <div>
                        <h3>{b.service}</h3>
                        <p style={{color:'var(--white-60)',fontSize:14}}>Worker: {b.workerName} ({b.workerLocalId})</p>
                      </div>
                      <span className={`badge ${b.status === 'completed' ? 'badge-success' : b.status === 'in_progress' ? 'badge-purple' : 'badge-warning'}`}>
                        {b.status}
                      </span>
                    </div>
                    <div className={styles.bookingMeta}>
                      <span>📍 {b.address}</span>
                      <span>📅 {b.scheduledDate}</span>
                      <span className={`badge ${b.paymentStatus === 'paid' ? 'badge-success' : 'badge-warning'}`}>
                        💳 {b.paymentStatus}
                      </span>
                    </div>
                    {b.paymentStatus === 'unpaid' && (
                      <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 14 }}>
                        <button
                          className="btn btn-gold btn-sm"
                          onClick={() => handlePayment(b)}
                          disabled={payLoading[b.id]}
                        >
                          {payLoading[b.id] ? <><span className="spinner" style={{width:12,height:12,borderWidth:2}}></span> Processing...</> : '💳 Pay Now ($50.00)'}
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>

      {/* Booking Modal */}
      {bookingWorker && (
        <div className={styles.modalOverlay} onClick={() => setBookingWorker(null)}>
          <div className={styles.modal} onClick={e => e.stopPropagation()}>
            <button className={styles.modalClose} onClick={() => setBookingWorker(null)}>✕</button>
            <h2>Book <span className="gradient-text">{bookingWorker.fullName}</span></h2>
            <p style={{color:'var(--white-60)',fontSize:14,marginBottom:24}}>ID: {bookingWorker.localId}</p>
            {bookingSuccess ? (
              <div style={{textAlign:'center',padding:'24px 0'}}>
                <div style={{fontSize:48,marginBottom:16}}>🎉</div>
                <h3>Booking Confirmed!</h3>
                <p style={{color:'var(--white-60)',marginTop:8}}>Your booking has been submitted. The worker will contact you soon.</p>
                <button className="btn btn-gold" style={{marginTop:24,width:'100%'}} onClick={() => { setBookingWorker(null); setActiveTab('bookings'); }}>
                  View My Bookings
                </button>
              </div>
            ) : (
              <form onSubmit={handleBook} style={{display:'flex',flexDirection:'column',gap:16}}>
                <div className="form-group">
                  <label className="form-label">Service Needed</label>
                  <select className="form-select" value={selectedService} onChange={e => setSelectedService(e.target.value)}>
                    <option value="">Select service</option>
                    {bookingWorker.skills?.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Address *</label>
                  <input className="form-input" value={bookingForm.address} onChange={e => setBookingForm(p=>({...p,address:e.target.value}))} placeholder="Your full address" required />
                </div>
                <div className="form-group">
                  <label className="form-label">Preferred Date *</label>
                  <input className="form-input" type="date" value={bookingForm.date} onChange={e => setBookingForm(p=>({...p,date:e.target.value}))} required />
                </div>
                <div className="form-group">
                  <label className="form-label">Notes (Optional)</label>
                  <textarea className="form-input" value={bookingForm.notes} onChange={e => setBookingForm(p=>({...p,notes:e.target.value}))} placeholder="Describe the issue..." rows={3} style={{resize:'vertical'}} />
                </div>
                <button type="submit" className="btn btn-gold btn-full btn-lg" disabled={bookingLoading}>
                  {bookingLoading ? <><span className="spinner"></span> Booking...</> : '✅ Confirm Booking'}
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
