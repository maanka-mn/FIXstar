'use client';
import { useState } from 'react';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from '@/lib/firebase';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import styles from '../../customer/page.module.css';

export default function WorkerLoginPage() {
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const router = useRouter();

  const handleChange = (e) => setForm(p => ({ ...p, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.email || !form.password) return setError('Please fill all fields.');
    setLoading(true); setError('');
    try {
      const cred = await signInWithEmailAndPassword(auth, form.email, form.password);
      const workerDoc = await getDoc(doc(db, 'workers', cred.user.uid));
      if (!workerDoc.exists()) {
        setError('Worker account not found.');
        return;
      }
      const data = workerDoc.data();
      localStorage.setItem('fixstar_worker', JSON.stringify({
        uid: data.uid, localId: data.localId, name: data.fullName,
        email: data.email, role: 'worker', status: data.status,
      }));
      router.push('/worker/dashboard');
    } catch (err) {
      if (err.code === 'auth/invalid-credential') {
        setError('Invalid email or password.');
      } else {
        setError('Login failed. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.page}>
      <div className={styles.bg}>
        <div className={styles.orb1}></div>
        <div className={styles.orb2}></div>
      </div>
      <div className={styles.card}>
        <Link href="/" className={styles.logo}>
          <span className={styles.logoStar}>★</span>
          <span>FIX<span style={{color:'var(--gold)'}}>Star</span></span>
        </Link>
        <h1 className={styles.title}>Worker Login</h1>
        <p className={styles.subtitle}>Access your dashboard, jobs, and earnings</p>

        <form onSubmit={handleSubmit} style={{display:'flex',flexDirection:'column',gap:16}}>
          <div className="form-group">
            <label className="form-label">Email Address</label>
            <input className="form-input" type="email" name="email" value={form.email} onChange={handleChange} placeholder="you@example.com" />
          </div>
          <div className="form-group">
            <label className="form-label">Password</label>
            <input className="form-input" type="password" name="password" value={form.password} onChange={handleChange} placeholder="Your password" />
          </div>
          {error && <p className={styles.error}>{error}</p>}
          <button id="worker-login-btn" type="submit" className="btn btn-gold btn-full btn-lg" disabled={loading} style={{marginTop:8}}>
            {loading ? <><span className="spinner"></span> Logging in...</> : '🔑 Login to Dashboard'}
          </button>
        </form>

        <div className="divider"></div>
        <div style={{textAlign:'center',display:'flex',flexDirection:'column',gap:8}}>
          <p className={styles.workerLink}>
            New worker? <Link href="/auth/worker/register" className={styles.link}>Register here</Link>
          </p>
          <p className={styles.workerLink}>
            Are you a customer? <Link href="/auth/customer" className={styles.link}>Customer login</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
