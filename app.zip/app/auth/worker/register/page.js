'use client';
import { useState } from 'react';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc, collection, getDocs, serverTimestamp } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { auth, db, storage } from '@/lib/firebase';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import styles from './page.module.css';

const serviceCategories = [
  'Cooling Systems (AC / Refrigerator)',
  'Washing Machine Repair',
  'Furniture Fixing & Making',
  'Electronic Machines',
  'Electrical Installation',
  'Plumbing & Piping',
  'Construction & Building Design',
];

export default function WorkerRegisterPage() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [form, setForm] = useState({
    fullName: '', email: '', phone: '', password: '', confirmPassword: '',
    skills: [], experience: '', bio: '',
    idDoc: null, certDoc: null,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const handleSkill = (skill) => {
    setForm(prev => ({
      ...prev,
      skills: prev.skills.includes(skill)
        ? prev.skills.filter(s => s !== skill)
        : [...prev.skills, skill],
    }));
  };

  const handleFile = (e) => {
    const { name, files } = e.target;
    setForm(prev => ({ ...prev, [name]: files[0] }));
  };

  const nextStep = () => {
    setError('');
    if (step === 1) {
      if (!form.fullName || !form.email || !form.phone || !form.password) {
        return setError('Please fill all required fields.');
      }
      if (form.password !== form.confirmPassword) {
        return setError('Passwords do not match.');
      }
      if (form.password.length < 6) {
        return setError('Password must be at least 6 characters.');
      }
    }
    if (step === 2 && form.skills.length === 0) {
      return setError('Please select at least one skill.');
    }
    setStep(s => s + 1);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.idDoc) return setError('Please upload your ID document.');
    setLoading(true);
    setError('');

    try {
      // Create Firebase Auth user
      const cred = await createUserWithEmailAndPassword(auth, form.email, form.password);
      const uid = cred.user.uid;

      // Generate Local ID
      const workersSnap = await getDocs(collection(db, 'workers'));
      const localId = `FS-${String(workersSnap.size + 1).padStart(6, '0')}`;

      // Upload ID document
      let idDocUrl = '', certDocUrl = '';
      const idRef = ref(storage, `workers/${uid}/id_document`);
      await uploadBytes(idRef, form.idDoc);
      idDocUrl = await getDownloadURL(idRef);

      if (form.certDoc) {
        const certRef = ref(storage, `workers/${uid}/certificate`);
        await uploadBytes(certRef, form.certDoc);
        certDocUrl = await getDownloadURL(certRef);
      }

      // Save to Firestore
      await setDoc(doc(db, 'workers', uid), {
        uid, localId,
        fullName: form.fullName,
        email: form.email,
        phone: form.phone,
        skills: form.skills,
        experience: form.experience,
        bio: form.bio,
        idDocUrl, certDocUrl,
        status: 'pending',
        role: 'worker',
        stripeAccountId: null,
        stripeOnboarded: false,
        earnings: 0,
        jobsCompleted: 0,
        rating: 0,
        createdAt: serverTimestamp(),
      });

      // Store session
      localStorage.setItem('fixstar_worker', JSON.stringify({
        uid, localId, name: form.fullName, email: form.email, role: 'worker', status: 'pending',
      }));

      setStep(4); // Success step
    } catch (err) {
      if (err.code === 'auth/email-already-in-use') {
        setError('Email already registered. Please login.');
      } else {
        setError('Registration failed. Please try again.');
      }
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.page}>
      <div className={styles.bg}>
        <div className={styles.orb1}></div>
        <div className={styles.orb2}></div>
      </div>

      <div className={styles.container}>
        <Link href="/" className={styles.logo}>
          <span className={styles.logoStar}>★</span>
          <span>FIX<span style={{color:'var(--gold)'}}>Star</span></span>
        </Link>

        {/* Progress */}
        {step < 4 && (
          <div className={styles.progress}>
            {[1,2,3].map(n => (
              <div key={n} className={`${styles.progressStep} ${step >= n ? styles.active : ''}`}>
                <div className={styles.progressDot}>{n}</div>
                <span>{n===1 ? 'Account' : n===2 ? 'Skills' : 'Documents'}</span>
              </div>
            ))}
          </div>
        )}

        <div className={styles.card}>
          {/* Step 1 — Account Info */}
          {step === 1 && (
            <div className="animate-fade-up">
              <h1 className={styles.title}>Create Worker Account</h1>
              <p className={styles.subtitle}>Join FIXStar and start earning by offering your skills</p>
              <div className={styles.formGrid}>
                <div className="form-group">
                  <label className="form-label">Full Name *</label>
                  <input className="form-input" name="fullName" value={form.fullName} onChange={handleChange} placeholder="Your full name" />
                </div>
                <div className="form-group">
                  <label className="form-label">Phone Number *</label>
                  <input className="form-input" name="phone" value={form.phone} onChange={handleChange} placeholder="+1 234 567 8900" />
                </div>
                <div className="form-group" style={{gridColumn:'1/-1'}}>
                  <label className="form-label">Email Address *</label>
                  <input className="form-input" type="email" name="email" value={form.email} onChange={handleChange} placeholder="you@example.com" />
                </div>
                <div className="form-group">
                  <label className="form-label">Password *</label>
                  <input className="form-input" type="password" name="password" value={form.password} onChange={handleChange} placeholder="Min. 6 characters" />
                </div>
                <div className="form-group">
                  <label className="form-label">Confirm Password *</label>
                  <input className="form-input" type="password" name="confirmPassword" value={form.confirmPassword} onChange={handleChange} placeholder="Repeat password" />
                </div>
              </div>
            </div>
          )}

          {/* Step 2 — Skills */}
          {step === 2 && (
            <div className="animate-fade-up">
              <h1 className={styles.title}>Your Skills & Experience</h1>
              <p className={styles.subtitle}>Select all the services you can provide</p>
              <div className={styles.skillsGrid}>
                {serviceCategories.map(skill => (
                  <button
                    key={skill}
                    type="button"
                    className={`${styles.skillBtn} ${form.skills.includes(skill) ? styles.skillActive : ''}`}
                    onClick={() => handleSkill(skill)}
                  >
                    {form.skills.includes(skill) && <span>✓ </span>}
                    {skill}
                  </button>
                ))}
              </div>
              <div className="form-group" style={{marginTop:24}}>
                <label className="form-label">Years of Experience</label>
                <select className="form-select" name="experience" value={form.experience} onChange={handleChange}>
                  <option value="">Select experience</option>
                  <option>Less than 1 year</option>
                  <option>1-3 years</option>
                  <option>3-5 years</option>
                  <option>5-10 years</option>
                  <option>10+ years</option>
                </select>
              </div>
              <div className="form-group" style={{marginTop:16}}>
                <label className="form-label">Short Bio</label>
                <textarea className="form-input" name="bio" value={form.bio} onChange={handleChange} rows={3} placeholder="Describe your expertise..." style={{resize:'vertical'}} />
              </div>
            </div>
          )}

          {/* Step 3 — Documents */}
          {step === 3 && (
            <form onSubmit={handleSubmit} className="animate-fade-up">
              <h1 className={styles.title}>Upload Documents</h1>
              <p className={styles.subtitle}>Your documents are securely stored and only reviewed by our admin team</p>

              <div className={styles.uploadBox}>
                <label className={styles.uploadLabel} htmlFor="idDoc">
                  <span className={styles.uploadIcon}>🪪</span>
                  <span className={styles.uploadText}>
                    {form.idDoc ? form.idDoc.name : 'Upload ID Document *'}
                  </span>
                  <span className={styles.uploadSub}>Passport, National ID, or Driver License</span>
                </label>
                <input id="idDoc" type="file" name="idDoc" accept="image/*,.pdf" onChange={handleFile} style={{display:'none'}} />
              </div>

              <div className={styles.uploadBox} style={{marginTop:16}}>
                <label className={styles.uploadLabel} htmlFor="certDoc">
                  <span className={styles.uploadIcon}>📜</span>
                  <span className={styles.uploadText}>
                    {form.certDoc ? form.certDoc.name : 'Upload Work Certificate (Optional)'}
                  </span>
                  <span className={styles.uploadSub}>Any professional certification or license</span>
                </label>
                <input id="certDoc" type="file" name="certDoc" accept="image/*,.pdf" onChange={handleFile} style={{display:'none'}} />
              </div>

              <div className={styles.notice}>
                <span>ℹ️</span>
                <p>After submission, your account will be reviewed by our admin team. You will be notified once approved and assigned your Local Worker ID.</p>
              </div>

              {error && <p className={styles.error}>{error}</p>}

              <button type="submit" className="btn btn-gold btn-full btn-lg" disabled={loading} style={{marginTop:24}}>
                {loading ? <><span className="spinner"></span> Submitting...</> : '✓ Submit Application'}
              </button>
            </form>
          )}

          {/* Step 4 — Success */}
          {step === 4 && (
            <div className={`${styles.success} animate-fade-up`}>
              <div className={styles.successIcon}>🌟</div>
              <h1 className={styles.title}>Application Submitted!</h1>
              <p className={styles.subtitle}>
                Your worker application has been submitted successfully. Our admin team will review your documents and approve your account shortly.
              </p>
              <div className={styles.successInfo}>
                <span>📧 Check your email for updates</span>
                <span>⏰ Review takes 1-2 business days</span>
              </div>
              <Link href="/auth/worker/login" className="btn btn-gold btn-full" style={{marginTop:24}}>
                Go to Worker Login
              </Link>
            </div>
          )}

          {/* Navigation */}
          {step < 3 && (
            <>
              {error && <p className={styles.error} style={{marginTop:16}}>{error}</p>}
              <div className={styles.navBtns}>
                {step > 1 && (
                  <button className="btn btn-ghost" onClick={() => setStep(s => s-1)}>← Back</button>
                )}
                <button className="btn btn-gold" style={{marginLeft:'auto'}} onClick={nextStep}>
                  {step === 2 ? 'Next: Documents →' : 'Next: Skills →'}
                </button>
              </div>
            </>
          )}
        </div>

        <p className={styles.loginLink}>
          Already registered? <Link href="/auth/worker/login" className={styles.link}>Login here</Link>
        </p>
      </div>
    </div>
  );
}
