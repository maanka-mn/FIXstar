import './globals.css';

export const metadata = {
  title: 'FIXStar — Create & Repair Services',
  description: 'FIXStar connects you with trusted professionals for all your repair, maintenance, and construction needs. Book a worker in minutes.',
  keywords: 'repair services, home maintenance, electrician, plumber, AC repair, furniture fixing',
  openGraph: {
    title: 'FIXStar — Create & Repair Services',
    description: 'Book trusted professionals for repair & construction services.',
    type: 'website',
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </head>
      <body>{children}</body>
    </html>
  );
}
