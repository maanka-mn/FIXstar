'use client';
import { useState, useEffect } from 'react';
import { collection, getDocs, doc, updateDoc, deleteDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import styles from './page.module.css';

export default function AdminDashboard() {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState('overview');
  const [workers, setWorkers] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [commission, setCommission] = useState(15);

  useEffect(() => {
    const admin = localStorage.getItem('fixstar_admin');
    if (!admin) { router.push('/admin/secure-login'); return; }
    loadAll();
  }, []);

  const loadAll = async () => {
    setLoading(true);
    try {
      const [wSnap, cSnap, bSnap] = await Promise.all([
        getDocs(collection(db, 'workers')),
        getDocs(collection(db, 'customers')),
        getDocs(collection(db, 'bookings')),
      ]);
      setWorkers(wSnap.docs.map(d => ({ id: d.id, ...d.data() })));
      setCustomers(cSnap.docs.map(d => ({ id: d.id, ...d.data() })));
      setBookings(bSnap.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (e) { console.error(e); }
    setLoading(false);
  };

  const approveWorker = async (id) => {
    await updateDoc(doc(db, 'workers', id), { status: 'approved' });
    setWorkers(prev => prev.map(w => w.id === id ? { ...w, status: 'approved' } : w));
  };

  const rejectWorker = async (id) => {
    await updateDoc(doc(db, 'workers', id), { status: 'rejected' });
    setWorkers(prev => prev.map(w => w.id === id ? { ...w, status: 'rejected' } : w));
  };

  const deleteWorker = async (id) => {
    if (!confirm('Delete this worker?')) return;
    await deleteDoc(doc(db, 'workers', id));
    setWorkers(prev => prev.filter(w => w.id !== id));
  };

  const handleLogout = () => {
    localStorage.removeItem('fixstar_admin');
    router.push('/');
  };

  const pendingWorkers = workers.filter(w => w.status === 'pending');
  const approvedWorkers = workers.filter(w => w.status === 'approved');
  const totalRevenue = bookings.filter(b => b.paymentStatus === 'paid').length * 50;
  const platformEarnings = Math.floor(totalRevenue * commission / 100);

  if (loading) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '100vh' }}>
      <div className="spinner" style={{ width: 48, height: 48 }}></div>
    </div>
  );

  return (
    <div className={styles.layout}>
      {/* Sidebar */}
      <aside className={styles.sidebar}>
        <div className={styles.sidebarTop}>
          <Link href="/" className={styles.logo}>
            <span style={{ color: 'var(--gold)' }}>★</span> FIXStar
          </Link>
          <div className={styles.adminBadge}>🔐 Admin Panel</div>
        </div>
        <nav className={styles.sidebarNav}>
          {[
            { id: 'overview', icon: '📊', label: 'Overview' },
            { id: 'workers', icon: '👷', label: `Workers (${pendingWorkers.length} pending)` },
            { id: 'customers', icon: '👥', label: 'Customers' },
            { id: 'bookings', icon: '📋', label: 'All Bookings' },
            { id: 'payments', icon: '💰', label: 'Payments' },
            { id: 'settings', icon: '⚙️', label: 'Settings' },
          ].map(item => (
            <button key={item.id}
              className={`${styles.navItem} ${activeTab === item.id ? styles.navActive : ''}`}
              onClick={() => setActiveTab(item.id)}>
              <span>{item.icon}</span> {item.label}
              {item.id === 'workers' && pendingWorkers.length > 0 && (
                <span className={styles.badge}>{pendingWorkers.length}</span>
              )}
            </button>
          ))}
        </nav>
        <button className={styles.logoutBtn} onClick={handleLogout}>🚪 Logout</button>
      </aside>

      <main className={styles.main}>
        {/* Overview */}
        {activeTab === 'overview' && (
          <div className="animate-fade-in">
            <div className="page-header">
              <h1>Admin <span className="gradient-text">Dashboard</span></h1>
              <p>FIXStar platform overview</p>
            </div>
            <div className={styles.statsGrid}>
              {[
                { label: 'Total Workers', value: workers.length, icon: '👷', color: 'var(--purple-glow)', sub: `${approvedWorkers.length} active` },
                { label: 'Customers', value: customers.length, icon: '👥', color: 'var(--gold)', sub: 'registered' },
                { label: 'Total Bookings', value: bookings.length, icon: '📋', color: 'var(--success)', sub: `${bookings.filter(b=>b.status==='completed').length} completed` },
                { label: 'Platform Revenue', value: `$${platformEarnings}`, icon: '💰', color: 'var(--gold)', sub: `${commission}% commission` },
              ].map(s => (
                <div key={s.label} className={`card ${styles.statCard}`}>
                  <div className={styles.statIcon} style={{ color: s.color }}>{s.icon}</div>
                  <div className={styles.statValue} style={{ color: s.color }}>{s.value}</div>
                  <div className={styles.statLabel}>{s.label}</div>
                  <div className={styles.statSub}>{s.sub}</div>
                </div>
              ))}
            </div>

            {pendingWorkers.length > 0 && (
              <div className={styles.alertBanner}>
                <span>⚠️</span>
                <div>
                  <strong>{pendingWorkers.length} worker{pendingWorkers.length > 1 ? 's' : ''} awaiting approval</strong>
                  <p>Review their documents and approve or reject their applications.</p>
                </div>
                <button className="btn btn-gold btn-sm" onClick={() => setActiveTab('workers')}>
                  Review Now →
                </button>
              </div>
            )}
          </div>
        )}

        {/* Workers Tab */}
        {activeTab === 'workers' && (
          <div className="animate-fade-in">
            <div className="page-header">
              <h1>Manage <span className="gradient-text">Workers</span></h1>
              <p>{workers.length} total workers · {pendingWorkers.length} pending approval</p>
            </div>
            <div className={styles.tableWrap}>
              <table className={styles.table}>
                <thead>
                  <tr>
                    <th>Worker</th>
                    <th>Local ID</th>
                    <th>Skills</th>
                    <th>Status</th>
                    <th>Documents</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {workers.map(w => (
                    <tr key={w.id}>
                      <td>
                        <div className={styles.workerCell}>
                          <div className={styles.workerAvatar}>{w.fullName?.charAt(0)}</div>
                          <div>
                            <strong>{w.fullName}</strong>
                            <p>{w.email}</p>
                          </div>
                        </div>
                      </td>
                      <td><span className={styles.localId}>{w.localId}</span></td>
                      <td>
                        <div className={styles.skillTags}>
                          {w.skills?.slice(0,2).map(s => <span key={s} className={styles.skillTag}>{s}</span>)}
                          {w.skills?.length > 2 && <span className={styles.skillTag}>+{w.skills.length-2}</span>}
                        </div>
                      </td>
                      <td>
                        <span className={`badge ${w.status === 'approved' ? 'badge-success' : w.status === 'rejected' ? 'badge-danger' : 'badge-warning'}`}>
                          {w.status}
                        </span>
                      </td>
                      <td>
                        {w.idDocUrl ? (
                          <a href={w.idDocUrl} target="_blank" rel="noreferrer" className={styles.docLink}>📄 View ID</a>
                        ) : <span style={{color:'var(--white-60)',fontSize:13}}>None</span>}
                        {w.certDocUrl && (
                          <a href={w.certDocUrl} target="_blank" rel="noreferrer" className={styles.docLink} style={{marginLeft:8}}>📜 Cert</a>
                        )}
                      </td>
                      <td>
                        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                          {w.status === 'pending' && (
                            <>
                              <button className="btn btn-success btn-sm" onClick={() => approveWorker(w.id)}>✓ Approve</button>
                              <button className="btn btn-danger btn-sm" onClick={() => rejectWorker(w.id)}>✗ Reject</button>
                            </>
                          )}
                          {w.status === 'approved' && (
                            <button className="btn btn-danger btn-sm" onClick={() => rejectWorker(w.id)}>Suspend</button>
                          )}
                          <button className="btn btn-ghost btn-sm" onClick={() => deleteWorker(w.id)}>🗑</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Customers Tab */}
        {activeTab === 'customers' && (
          <div className="animate-fade-in">
            <div className="page-header">
              <h1>Manage <span className="gradient-text">Customers</span></h1>
              <p>{customers.length} registered customers</p>
            </div>
            <div className={styles.tableWrap}>
              <table className={styles.table}>
                <thead>
                  <tr><th>Customer</th><th>Email</th><th>Joined</th></tr>
                </thead>
                <tbody>
                  {customers.map(c => (
                    <tr key={c.id}>
                      <td>
                        <div className={styles.workerCell}>
                          {c.photo ? <img src={c.photo} alt="" className={styles.customerPhoto} /> : <div className={styles.workerAvatar}>{c.name?.charAt(0)}</div>}
                          <strong>{c.name}</strong>
                        </div>
                      </td>
                      <td style={{color:'var(--white-60)',fontSize:14}}>{c.email}</td>
                      <td style={{color:'var(--white-60)',fontSize:13}}>{c.createdAt?.toDate?.()?.toLocaleDateString() || 'N/A'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Bookings Tab */}
        {activeTab === 'bookings' && (
          <div className="animate-fade-in">
            <div className="page-header">
              <h1>All <span className="gradient-text">Bookings</span></h1>
              <p>{bookings.length} total bookings</p>
            </div>
            <div className={styles.tableWrap}>
              <table className={styles.table}>
                <thead>
                  <tr><th>Service</th><th>Customer</th><th>Worker</th><th>Date</th><th>Status</th><th>Payment</th></tr>
                </thead>
                <tbody>
                  {bookings.map(b => (
                    <tr key={b.id}>
                      <td><strong>{b.service}</strong></td>
                      <td style={{fontSize:14}}>{b.customerName}</td>
                      <td style={{fontSize:14}}>{b.workerName} <span style={{color:'var(--gold)',fontSize:12}}>({b.workerLocalId})</span></td>
                      <td style={{color:'var(--white-60)',fontSize:13}}>{b.scheduledDate}</td>
                      <td>
                        <span className={`badge ${b.status === 'completed' ? 'badge-success' : b.status === 'in_progress' ? 'badge-purple' : 'badge-warning'}`}>
                          {b.status}
                        </span>
                      </td>
                      <td>
                        <span className={`badge ${b.paymentStatus === 'paid' ? 'badge-success' : 'badge-warning'}`}>
                          {b.paymentStatus}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Payments Tab */}
        {activeTab === 'payments' && (
          <div className="animate-fade-in">
            <div className="page-header">
              <h1>Payment <span className="gradient-text">Overview</span></h1>
              <p>Revenue and split tracking</p>
            </div>
            <div className={styles.paymentCards}>
              <div className={`card ${styles.payCard}`}>
                <div style={{fontSize:32,marginBottom:12}}>💰</div>
                <div className={styles.payValue}>${totalRevenue}</div>
                <div className={styles.payLabel}>Total Revenue</div>
              </div>
              <div className={`card ${styles.payCard}`}>
                <div style={{fontSize:32,marginBottom:12}}>🏢</div>
                <div className={styles.payValue} style={{color:'var(--gold)'}}>${platformEarnings}</div>
                <div className={styles.payLabel}>FIXStar Earnings ({commission}%)</div>
              </div>
              <div className={`card ${styles.payCard}`}>
                <div style={{fontSize:32,marginBottom:12}}>👷</div>
                <div className={styles.payValue} style={{color:'var(--success)'}}>${totalRevenue - platformEarnings}</div>
                <div className={styles.payLabel}>Worker Payouts ({100-commission}%)</div>
              </div>
            </div>
          </div>
        )}

        {/* Settings Tab */}
        {activeTab === 'settings' && (
          <div className="animate-fade-in">
            <div className="page-header">
              <h1>Platform <span className="gradient-text">Settings</span></h1>
              <p>Configure FIXStar platform settings</p>
            </div>
            <div className={`card ${styles.settingsCard}`}>
              <h3>💰 Commission Rate</h3>
              <p style={{color:'var(--white-60)',fontSize:14,margin:'8px 0 20px'}}>
                Percentage FIXStar takes from each payment. Workers receive the remaining amount.
              </p>
              <div style={{display:'flex',alignItems:'center',gap:16}}>
                <input
                  type="range" min="5" max="40" value={commission}
                  onChange={e => setCommission(Number(e.target.value))}
                  className={styles.slider}
                />
                <div className={styles.commissionDisplay}>
                  <span className={styles.commissionValue}>{commission}%</span>
                  <span style={{color:'var(--white-60)',fontSize:13}}>FIXStar</span>
                </div>
                <div className={styles.commissionDisplay}>
                  <span className={styles.commissionValue} style={{color:'var(--success)'}}>{100-commission}%</span>
                  <span style={{color:'var(--white-60)',fontSize:13}}>Worker</span>
                </div>
              </div>
              <button className="btn btn-gold" style={{marginTop:24}}>Save Settings</button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
