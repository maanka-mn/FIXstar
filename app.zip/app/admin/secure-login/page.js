'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import styles from './page.module.css';

export default function AdminLoginPage() {
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const router = useRouter();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/auth/admin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'Invalid credentials.'); return; }
      localStorage.setItem('fixstar_admin', JSON.stringify({ token: data.token, role: 'admin' }));
      router.push('/admin/dashboard');
    } catch { setError('Connection failed. Try again.'); }
    finally { setLoading(false); }
  };

  return (
    <div className={styles.page}>
      <div className={styles.bg}>
        <div className={styles.orb1}></div>
        <div className={styles.orb2}></div>
        <div className={styles.gridBg}></div>
      </div>
      <div className={styles.card}>
        <div className={styles.adminBadge}>🔐 Admin Access Only</div>
        <h1 className={styles.title}>Admin <span className="gradient-text">Portal</span></h1>
        <p className={styles.subtitle}>This area is restricted to authorized administrators only.</p>
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div className="form-group">
            <label className="form-label">Admin Password</label>
            <input
              id="admin-password-input"
              className="form-input"
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="Enter admin password"
              autoComplete="off"
              required
            />
          </div>
          {error && <p className={styles.error}>{error}</p>}
          <button id="admin-login-btn" type="submit" className="btn btn-gold btn-full btn-lg" disabled={loading} style={{ marginTop: 8 }}>
            {loading ? <><span className="spinner"></span> Verifying...</> : '🔐 Access Dashboard'}
          </button>
        </form>
        <div className="divider"></div>
        <Link href="/" className={styles.backLink}>← Back to FIXStar</Link>
      </div>
    </div>
  );
}
