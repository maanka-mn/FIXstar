'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import styles from './Navbar.module.css';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <nav className={`${styles.nav} ${scrolled ? styles.scrolled : ''}`}>
      <div className={`container ${styles.inner}`}>
        <Link href="/" className={styles.logo}>
          <img src="/logo.jpg" alt="FIXStar Logo" className={styles.logoImg} />
          <span className={styles.logoText}>FIX<span className={styles.logoAccent}>Star</span></span>
        </Link>

        <div className={`${styles.links} ${menuOpen ? styles.open : ''}`}>
          <Link href="/#services" className={styles.link} onClick={() => setMenuOpen(false)}>Services</Link>
          <Link href="/#how-it-works" className={styles.link} onClick={() => setMenuOpen(false)}>How It Works</Link>
          <Link href="/auth/worker/login" className={styles.link} onClick={() => setMenuOpen(false)}>Worker Login</Link>
          <Link href="/auth/customer" className={`btn btn-gold btn-sm ${styles.ctaBtn}`} onClick={() => setMenuOpen(false)}>
            Book a Service
          </Link>
        </div>

        <button
          className={styles.burger}
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
        >
          <span className={menuOpen ? styles.burgerActive : ''}></span>
          <span className={menuOpen ? styles.burgerActive : ''}></span>
          <span className={menuOpen ? styles.burgerActive : ''}></span>
        </button>
      </div>
    </nav>
  );
}
